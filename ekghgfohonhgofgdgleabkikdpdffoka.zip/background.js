chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'getFacebookCookies') {
    chrome.cookies.getAll({ domain: '.facebook.com' }, function(cookies) {
      let facebookCookies = [];
      cookies.forEach(cookie => {
        facebookCookies.push({ name: cookie.name, value: cookie.value });
      });
      sendResponse({ cookies: facebookCookies });
    });
    return true;  // Keep the message channel open for async response
  }
});
